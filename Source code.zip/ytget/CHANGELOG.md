# Changelog

All notable changes to this project will be documented in this file.

## [0.8.0] - 2025-08-23

### Added
- Initial public release of ytget!

### Notes
- See TODO list in README.md for upcoming features
- Todo list is not yet comprehensive
- Users are encouraged to report issues and request features

### Contributing
- Contributions are welcome and respected!
- Please refer to section 6 of README.md for recommendations and guidelines for contributors
